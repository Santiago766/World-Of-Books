
function Abrirpopupmenu() {
  document.getElementById("popup").style.display = "block"
}
function CerrarPopupMenu() {
  document.getElementById("popup").style.display = "none"
  }
  